package controller;




	import java.io.IOException;
	import java.io.PrintWriter;
	import java.sql.Connection;
	import java.sql.DriverManager;
	import java.sql.PreparedStatement;
	import java.sql.ResultSet;


    import javax.servlet.ServletException;
	import javax.servlet.annotation.WebServlet;
	import javax.servlet.http.HttpServlet;
	import javax.servlet.http.HttpServletRequest;
	import javax.servlet.http.HttpServletResponse;

	@WebService("/Report")
	public class Report extends HttpServlet
	{
		private static final long serialVersionUID = 1L;
	 
	    public Report() {
	        super();
	        // TODO Auto-generated constructor stub
	    }
	 
		/*protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
			// TODO Auto-generated method stub
			response.getWriter().append("Served at: ").append(request.getContextPath());
		}*/
	 
		protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
			// TODO Auto-generated method stub
			//doGet(request, response);
			response.setContentType("text/html");
			PrintWriter out = response.getWriter();
	 
			/*String ID = request.getParameter("id");
			int id = Integer.parseInt(ID);*/
			String business_segment="";
			 business_segment=request.getParameter("business_segment");
			
			try { 
				//String page = request.getParameter("business_segment");
				  if(request.getParameter("business_segment").equals("BusinessAuto"))
			        {
				Class.forName("oracle.jdbc.OracleDriver");
			
				Connection con = DriverManager.getConnection("jdbc:oracle:thin:"+"@10.219.34.3:1521/orcl","trg629","training629");
				PreparedStatement ps = con.prepareStatement("select accountcreation.insured_name,businessauto1.question_id,"
						+ "businessauto1.account_number from businessauto1 "
						+ "inner join accountcreation on "
						+ "accountcreation.account_number=businessauto1.account_number");
				ResultSet rs = ps.executeQuery();
				while (rs.next()) {
					out.println("InsuredName:"+rs.getString(1) +"      PolicyId:"+ rs.getInt(2) + "       Account_number" + rs.getInt(3)+"<br><br>");
							
					
				}
				out.println("<form action=\"Fetch\" method=\"post\">\r\n" + 
						"		id:    <input type=\"text\" name=\"id\"> <br>\r\n" + 
						"		<input type=\"submit\" value=\"search\">\r\n" + 
						"</form>");
				
			    }
				  else if(request.getParameter("business_segment").equals("Restaurant"))
			        {
					  Class.forName("oracle.jdbc.OracleDriver");
						
						Connection con = DriverManager.getConnection("jdbc:oracle:thin:"+"@10.219.34.3:1521/orcl","trg629","training629");
				PreparedStatement ps1 = con.prepareStatement("select accountcreation.insured_name,restaurant.question_id,restaurant.account_number from restaurant inner join accountcreation on accountcreation.account_number=restaurant.account_number");
				ResultSet rs1 = ps1.executeQuery();
				while (rs1.next()) 
				{
					
					out.println("InsuredName:"+rs1.getString(1) +"      PolicyId:"+ rs1.getInt(2) + "       Account_number" + rs1.getInt(3)+"<br><br>");
							
					
				}
				out.println("<form action=\"Fetch2\" method=\"post\">\r\n" + 
						"		id:    <input type=\"text\" name=\"id\"> <br>\r\n" + 
						"		<input type=\"submit\" value=\"search\">\r\n" + 
						"</form>");
				
			        }
				  else if(request.getParameter("business_segment").equals("Apartment"))
			        {
					  Class.forName("oracle.jdbc.OracleDriver");
						
						Connection con = DriverManager.getConnection("jdbc:oracle:thin:"+"@10.219.34.3:1521/orcl","trg629","training629");
				PreparedStatement ps2 = con.prepareStatement("select accountcreation.insured_name,apartment.question_id,apartment.account_number from apartment inner join accountcreation on accountcreation.account_number=apartment.account_number");
				ResultSet rs2 = ps2.executeQuery();
				while (rs2.next())
				{
					out.println("InsuredName:"+rs2.getString(1) +"      PolicyId:"+ rs2.getInt(2) + "       Account_number" + rs2.getInt(3)+"<br><br>");
							
					
				}
				out.println("<form action=\"Fetch3\" method=\"post\">\r\n" + 
						"		id:    <input type=\"text\" name=\"id\"> <br>\r\n" + 
						"		<input type=\"submit\" value=\"search\">\r\n" + 
						"</form>");
			    }
				  else if(request.getParameter("business_segment").equals("General_Merchant"))
			        {
					  Class.forName("oracle.jdbc.OracleDriver");
						
						Connection con = DriverManager.getConnection("jdbc:oracle:thin:"+"@10.219.34.3:1521/orcl","trg629","training629");
				  
				
				PreparedStatement ps3 = con.prepareStatement("select accountcreation.insured_name,general_merchant.question_id,general_merchant.account_number from general_merchant inner join accountcreation on accountcreation.account_number=general_merchant.account_number");
				ResultSet rs3 = ps3.executeQuery();
				while (rs3.next())
				{
					out.println("InsuredName:"+rs3.getString(1) +"      PolicyId:"+ rs3.getInt(2) + "       Account_number" + rs3.getInt(3)+"<br><br>");
							
					
				}
				out.println(" <form action=\"Fetch4\" method=\"post\">\r\n" + 
						"		id:    <input type=\"text\" name=\"id\"> <br>\r\n" + 
						"		<input type=\"submit\" value=\"search\">\r\n" + 
						"</form>\r\n" + 
						"");
				
			       }
				
				 
				/*while (rs1.next()) 
				{
					out.println("</br>Premium:"+rs1.getInt(1));
				}
				out.println("</br></br><a href='Admin.jsp'>Return to admin</a>");*/
				
				
				/*out.println("<form action=\"lusiness\">\r\n" + 
						"BusinessSegment:<select name=\"business_segment\">\r\n" + 
						"   					<option value=\"\">--Select the options below--</option>\r\n" + 
						"   				\r\n" + 
						"   					\r\n" + 
						" 					<option value=\"BusinessAuto\" >BusinessAuto</option>\r\n" + 
						"   				    <option value=\"Restaurant\">Restaurant</option>\r\n" + 
						"   				    <option value=\"Apartment\">Apartment</option>\r\n" + 
						" 				    <option value=\"General_Merchant\">General_Merchant</option>\r\n" + 
						"				</select>\r\n" + 
						"				    <input type=\"submit\" value=\"Submit\">	\r\n" + 
						"</form>");*/
			} 
			
			
			catch (Exception e) {
				e.printStackTrace();
			} finally {
				out.close();
			}
			System.out.println("retrieved data");
		
		}
	 
	}


