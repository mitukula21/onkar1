package com.DAO;


	import java.sql.Connection;
	import java.sql.PreparedStatement;
	import java.sql.ResultSet;
	import java.sql.SQLException;
	import java.sql.Statement;

import com.Bean.AccountBean;
import com.Connections.ConnectionsCom;



	public class QuesInsertDao {
		AccountBean accbean=new AccountBean();
		Connection con=null;
		ResultSet resultSet = null;
		ResultSet ac=null;
		PreparedStatement pstmt = null;

		public int PolIns(int res) {
			//System.out.println(accbean.getAccNo());
			// TODO Auto-generated method stub
			try {
				con=ConnectionsCom.getcon();
				String is_acc="select account_number from accounts where ";
				pstmt.executeUpdate(is_acc);
				String ins_str ="insert into policy values(pol_seq.NEXTVAL,?,?)";
				 
				pstmt = con.prepareStatement(ins_str);
				//int acno = pstmt.executeUpdate();
				//pstmt = con.prepareStatement("SELECT account_number from accounts");
				pstmt.setInt(1,res);
				//pstmt.setLong(2,/*accbean.getAccNo()*/1003);
				
				
				int updateCount = pstmt.executeUpdate();
				  pstmt = con.prepareStatement("SELECT pol_seq.CURRVAL FROM DUAL");
					resultSet=pstmt.executeQuery();
				  
				  if(updateCount==1) {
				  if(resultSet.next())
					{
					  String pol=resultSet.getString(1);
					  System.out.println("1 row inserted into policy table");
					  return Integer.parseInt(pol);
								
					}
				 
				  }
				  else {
					  System.out.println("insertion not done");
				  }
				
			}catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			return 0;
		}
		
		/*public int QuesIns(int qid) {
			try {
				con=ConnectionsCom.getcon();
				String ins_str ="insert into policy_details values(?,?,?)";
				  
				pstmt = con.prepareStatement(ins_str);
				  
				pstmt.setInt(1,res);
				pstmt.setLong(2,accbean.getAccNo()1003);
				
				
				int updateCount = pstmt.executeUpdate();
				  pstmt = con.prepareStatement("SELECT pol_seq.CURRVAL FROM DUAL");
					resultSet=pstmt.executeQuery();
				  
				  if(updateCount==1) {
				  if(resultSet.next())
					{
					  String pol=resultSet.getString(1);
					  System.out.println("1 row inserted into policy table");
					  return Integer.parseInt(pol);
								
					}
				 
				  }
				  else {
					  System.out.println("insertion not done");
				  }
				
			}catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			return 0;
			
		}*/

		

	}



