package com.Service;

import java.util.HashMap;

import javax.servlet.http.HttpSession;

import com.DAO.PremiumDao;
import com.DAO.QuesInsertDao;


public class PremiumService {
	public int CalculatePremium(HashMap<String, String> ans) {
		// TODO Auto-generated method stub
		PremiumDao predao=new PremiumDao();
		int res=predao.CalDao(ans); 
		
		QuesInsertDao polins=new QuesInsertDao();
		int res1=polins.PolIns(res);
		
		return res;

}
}
