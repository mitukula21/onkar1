

import static org.junit.Assert.*;

import java.sql.Date;
import java.time.LocalDate;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Assert;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Ignore;
import org.junit.Test;

import com.nag.AccountBean;

import dao.AccountDAO;



public class AccountTest 
{

	static AccountDAO dao;
	static AccountBean account;

	@BeforeClass
	public static void initialize() {
		System.out.println("in before class");
		dao = new AccountDAO();
		account = new AccountBean();
	}

	@Test
	public void testAddAccount() 
	{

		assertNotNull(dao.addAccount(account));

	}

	
	@Ignore
	@Test
	public void testAddDonarDetails1() 
	{
		// increment the number next time you test for positive test case
		assertEquals(1001, dao.addAccount(account));
	}


	@Test
	public void testAddDonarDetails2()
	{

		account.setInsured_name("Nagesh");
		account.setInsured_street("Mettukuppam");
		account.setInsured_city("Chennai");
		account.setInsured_state("Tamilnadu");
		account.setInsured_zip(500078);
		account.setBusiness_segment("Restaurant");
		
		equals( dao.addAccount(account));
		
	}

	
}




