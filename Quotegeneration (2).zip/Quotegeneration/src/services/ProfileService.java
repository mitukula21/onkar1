package services;

import com.nag.AccountBean;
import com.nag.ProfileBean;

import dao.AccountDAO;
import dao.ProfileDAO;

public class ProfileService
{
	
	 public int addProfileService(String username,String password,String rolecode)
	 {
		
		 
		 ProfileDAO bookDAO = new  ProfileDAO();
		 ProfileBean studentBean = new ProfileBean();
		 //wrap up all the four field values into bean
		 
		 studentBean.setUsername(username);
		 studentBean.setPassword(password);
		 studentBean.setRolecode(rolecode);
		
		 int updateResult = 0;
		 try
		 {
			 updateResult = ProfileDAO.addProfile(studentBean);
			 return updateResult;
		 }
		 catch(Exception ex)
		 {
			 System.out.println(ex.toString());
			 return 0;
		 }
	 }
	 
	 
	 
	 
	}




