package controller;


	
	import java.io.IOException;

	import javax.servlet.RequestDispatcher;
	import javax.servlet.ServletException;
	import javax.servlet.http.HttpServlet;
	import javax.servlet.http.HttpServletRequest;
	import javax.servlet.http.HttpServletResponse;

	
import services.ProfileService;


	

	public class ProfileController extends HttpServlet
	{
	public  void doGet(HttpServletRequest request,HttpServletResponse response) 
	   throws ServletException,IOException 
	{
		RequestDispatcher rd = null;
		RequestDispatcher req = null;
		String username="";
		String password="";
		String rolecode="";
		
		
		username=request.getParameter("username");
		password=request.getParameter("password");
		rolecode=request.getParameter("rolecode");
		
		 
		 ProfileService bookService = new ProfileService();
			
		
			
		   int updateCount = bookService.addProfileService(username, password, rolecode);
				
				System.out.println("inserted "+updateCount+" record   Success");
				
				if (updateCount==1)
				{
					rd = request.getRequestDispatcher("/Admin.jsp");				
				}
				
				
				else 
				{
					rd = request.getRequestDispatcher("/error.jsp");
				}
				rd.forward(request, response);
				
			}
	
		 
	}

		





		
		
		
		
		
		
		
		
		
		
		
		
			
			
			/*AccountService bookService = new AccountService();
		
	   int updateCount = bookService.addStudentService(insured_name,insured_street,insured_city,insured_state,insured_zip,business_segment,account_number);
			
			System.out.println("inserted "+updateCount+" record   Success");
			
			if (updateCount==1)
			{
				
				rd = request.getRequestDispatcher("/success.jsp");
				
			} else
			{
				rd = request.getRequestDispatcher("/error.jsp");
			}
			rd.forward(request, response);
		}
			*/
			
			



