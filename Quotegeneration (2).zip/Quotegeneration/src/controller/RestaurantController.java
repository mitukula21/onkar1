package controller;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import services.RestaurantService;
 

 
public class RestaurantController extends HttpServlet
{
 
	public  void doGet(HttpServletRequest request,HttpServletResponse response) 
	   throws ServletException,IOException 
	{
		RequestDispatcher rd = null;
		RequestDispatcher req = null;
		String restauranttype="";
		 String restaurantSQFt="";
		 String numberofSprinklers="";
		 String noofCylindersinKitchen="";
		 String fineArts="";
		 String propertyDamage="";
		 String equipmentBreakdown="";
		 String liablityCoverage="";
		 String bodilyInjury="";
		 int account_number=0;
		String business_segment="";
 
 
		restauranttype=request.getParameter("restauranttype");
 
		restaurantSQFt=request.getParameter("restaurantSQFt");
 
		numberofSprinklers=request.getParameter("NumberofSprinklers");
		noofCylindersinKitchen=request.getParameter("NoofCylindersinKitchen");
		fineArts=request.getParameter("FineArts");
		propertyDamage=request.getParameter("PropertyDamage");
		equipmentBreakdown=request.getParameter("EquipmentBreakdown");
		liablityCoverage=request.getParameter("LiablityCoverage");
		bodilyInjury=request.getParameter("BodilyInjury");
 
		 String account_number1=request.getParameter("account_number");
		 account_number=Integer.parseInt(account_number1);
 
		 RestaurantService bookService = new RestaurantService();
 
 
 
		   int updateCount = bookService.addRestaurantService(restauranttype,restaurantSQFt,numberofSprinklers,noofCylindersinKitchen,fineArts,propertyDamage,equipmentBreakdown,liablityCoverage,bodilyInjury,account_number);
 
				System.out.println("inserted "+updateCount+" record   Success");
 
				if (updateCount==1)
				{
					rd = request.getRequestDispatcher("/Thanks.jsp");	
 
				} else 
				{
					rd = request.getRequestDispatcher("/error.jsp");	
				}
				rd.forward(request, response);
			}
 
 
 
}