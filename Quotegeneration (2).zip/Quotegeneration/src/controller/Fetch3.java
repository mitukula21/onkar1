package controller;
 
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
 
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
 
 
 
 
@WebServlet("/Fetch3")
public class Fetch3 extends HttpServlet
{
	private static final long serialVersionUID = 1L;
 
    public Fetch3() {
        super();
        // TODO Auto-generated constructor stub
    }
 
	/*protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}*/
 
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//doGet(request, response);
		response.setContentType("text/html");
		PrintWriter out = response.getWriter();
 
		String ID = request.getParameter("id");
		int id = Integer.parseInt(ID);
 
		try { 
			Class.forName("oracle.jdbc.OracleDriver");
 
			Connection con = DriverManager.getConnection("jdbc:oracle:thin:"+"@10.219.34.3:1521/orcl","trg629","training629");
			PreparedStatement ps = con.prepareStatement("\r\n" + 
					"select accountcreation.insured_name,accountcreation.insured_street,\r\n" + 
					"accountcreation.insured_city,accountcreation.insured_state,\r\n" + 
					"accountcreation.insured_zip,accountcreation.business_segment,\r\n" + 
					"accountcreation.account_number,apartment.question_id,\r\n" + 
					"apartment.q1,apartment.apartmentsqft,apartment.q2,\r\n" + 
					"apartment.numberofsprinklers,apartment.q3,apartment.buildyear,\r\n" + 
					"apartment.q4,apartment.propertydamage,apartment.q5,\r\n" + 
					"apartment.bodilyinjurylimit,apartment.q6,apartment.numberoffloors,\r\n" + 
					"apartment.q7,apartment.numberoffireexits,apartment.q8,apartment.assettheftlimit from accountcreation \r\n" + 
					"full outer join apartment on accountcreation.account_number=apartment.account_number where apartment.account_number=?");
PreparedStatement ps1 = con.prepareStatement("select sum(APARTMENTSQFT+NUMBEROFSPRINKLERS+BUILDYEAR+PROPERTYDAMAGE+BODILYINJURYLIMIT+NUMBEROFFLOORS+NUMBEROFFIREEXITS+ASSETTHEFTLIMIT) as sum from apartment where account_number=?");
			ps.setInt(1, id);
			ps1.setInt(1, id);
 
 
			ResultSet rs = ps.executeQuery();
			out.println("<html>" + 
					"<head>"
					+ "<html>\r\n" + 
					"<head>\r\n" + 
					"<meta http-equiv=\"Content-Type\" content=\"text/html; charset=ISO-8859-1\">\r\n" + 
					"<meta name=\"viewport\" content=\"width=device-width, initial-scale=1\">\r\n" + 
					"<meta http-equiv=\"Content-Type\" content=\"text/html; charset=utf-8\" />\r\n" + 
					"\r\n" + 
					"\r\n" + 
					"  <link rel=\"stylesheet\" href=\"https://m...content-available-to-author-only...n.com/bootstrap/3.4.0/css/bootstrap.min.css\">\r\n" + 
					"  <script src=\"https://a...content-available-to-author-only...s.com/ajax/libs/jquery/3.3.1/jquery.min.js\"></script>\r\n" + 
					"  <script src=\"https://m...content-available-to-author-only...n.com/bootstrap/3.4.0/js/bootstrap.min.js\"></script>\r\n" + 
					"<script type=\"application/x-javascript\"> addEventListener(\"load\", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>\r\n" + 
					"<!-- Custom Theme files -->\r\n" + 
					"<link href=\"css/style1.css\" rel=\"stylesheet\" type=\"text/css\" media=\"all\" />\r\n" + 
					"<!-- //Custom Theme files -->\r\n" + 
					"<!-- web font -->\r\n" + 
					"<link href='//fonts.googleapis.com/css?family=Open+Sans:400,300,600,700,800' rel='stylesheet' type='text/css'><!--web font-->\r\n" + 
					"<!-- //web font -->"+
					"<style>\r\n" + 
					"table, td, th \r\n" + 
					"{\r\n" + 
					"  border: 3px  solid white;\r\n" + 
					"  background: transparent; \r\n" + 
					" }\r\n" + 
					" </style>"
					+ "</head>" +
			"<body>" + 
			"<table border='1'>");
 
			while (rs.next()) {
 
 
				out.println( 
						"<tr>" + 
						"<td style=\"color: #FFF; font-style: bold; font-size:20px\">InsuredName: " + "</td><td  style=\"color: #FFF; font-style: bold; font-size:20px\" colspan='3'>"+rs.getString(1) +"</td>"+"</tr>"+
						"<tr><td style=\"color: #FFF; font-style: bold; font-size:20px\"> insured Street: "+ "</td><td style=\"color: #FFF; font-style: bold; font-size:20px\" colspan='3'>"+ rs.getString(2) +"</td>"+"</tr>"+ 
						"<tr><td style=\"color: #FFF; font-style: bold; font-size:20px\"> Insuredcity: " + "</td><td style=\"color: #FFF; font-style: bold; font-size:20px\" colspan='3'>"+ rs.getString(3)+"</td>"+"</tr>"+
						"<tr><td style=\"color: #FFF; font-style: bold; font-size:20px\"> Insured state: " + "</td><td  style=\"color: #FFF; font-style: bold; font-size:20px\"colspan='3'>"+ rs.getString(4)+ "</td>"+"</tr>"+
						"<tr><td style=\"color: #FFF; font-style: bold; font-size:20px\"> insuredZip: " + "</td><td style=\"color: #FFF; font-style: bold; font-size:20px\" colspan='3'>"+ rs.getInt(5)+ "</td>"+"</tr>"+
						"<tr><td style=\"color: #FFF; font-style: bold; font-size:20px\"> Businesssegment: " + "</td><td style=\"color: #FFF; font-style: bold; font-size:20px\" colspan='3'>"+ rs.getString(6)+ "</td>"+"</tr>"+
						"<tr><td style=\"color: #FFF; font-style: bold; font-size:20px\"> Accountnumber: " + "</td><td style=\"color: #FFF; font-style: bold; font-size:20px\" colspan='3'>"+ rs.getInt(7)+ "</td>"+"</tr>"+
 
						" <tr><td style=\"color: #FFF; font-style: bold; font-size:20px\">Policy id: " + "</td><td style=\"color: #FFF; font-style: bold; font-size:20px\" colspan='3'>"+ rs.getInt(8) + "</td>"+
 
 
						"<tr><td style=\"color: #FFF; font-style: bold; font-size:20px\"> question1: "+ "</td><td style=\"color: #FFF; font-style: bold; font-size:20px\">"+ rs.getString(9) + "</td><td style=\"color: #FFF; font-style: bold; font-size:20px\">"+ " Weightage1: " +"</td><td style=\"color: #FFF; font-style: bold; font-size:20px\">"+ rs.getString(10)+"</td></tr>"+
						"<tr><td style=\"color: #FFF; font-style: bold; font-size:20px\"> question2: " + "</td><td style=\"color: #FFF; font-style: bold; font-size:20px\">"+ rs.getString(11)+ "</td><td style=\"color: #FFF; font-style: bold; font-size:20px\">"+" Weightage2: " +"</td><td style=\"color: #FFF; font-style: bold; font-size:20px\">"+ rs.getString(12)+ "</td></tr>"+
						"<tr><td style=\"color: #FFF; font-style: bold; font-size:20px\"> question3: " + "</td><td style=\"color: #FFF; font-style: bold; font-size:20px\">"+ rs.getString(13)+ "</td><td style=\"color: #FFF; font-style: bold; font-size:20px\">"+" Weightage3: " + "</td><td style=\"color: #FFF; font-style: bold; font-size:20px\">"+rs.getString(14)+ "</td></tr>"+
						"<tr><td style=\"color: #FFF; font-style: bold; font-size:20px\"> question4: " + "</td><td style=\"color: #FFF; font-style: bold; font-size:20px\">"+ rs.getString(15)+ "</td><td style=\"color: #FFF; font-style: bold; font-size:20px\">"+" Weightage4: " +"</td><td style=\"color: #FFF; font-style: bold; font-size:20px\">"+ rs.getString(16)+ "</td></tr>"+
						"<tr><td style=\"color: #FFF; font-style: bold; font-size:20px\"> question5: " + "</td><td style=\"color: #FFF; font-style: bold; font-size:20px\">"+ rs.getString(17)+ "</td><td style=\"color: #FFF; font-style: bold; font-size:20px\">"+" Weightage5: " +"</td><td style=\"color: #FFF; font-style: bold; font-size:20px\">"+ rs.getString(18)+ "</td></tr>"+
						"<tr><td style=\"color: #FFF; font-style: bold; font-size:20px\"> question6: " + "</td><td style=\"color: #FFF; font-style: bold; font-size:20px\">"+ rs.getString(19)+ "</td><td style=\"color: #FFF; font-style: bold; font-size:20px\">"+" Weightage6: " + "</td><td style=\"color: #FFF; font-style: bold; font-size:20px\">"+rs.getString(20)+ "</td></tr>"+
						"<tr><td style=\"color: #FFF; font-style: bold; font-size:20px\"> question7: " + "</td><td style=\"color: #FFF; font-style: bold; font-size:20px\">"+ rs.getString(21)+ "</td><td style=\"color: #FFF; font-style: bold; font-size:20px\">"+" Weightage7: " + "</td><td style=\"color: #FFF; font-style: bold; font-size:20px\">"+rs.getString(22)+"</td></tr>"+
						"<tr><td style=\"color: #FFF; font-style: bold; font-size:20px\"> question8: " + "</td><td style=\"color: #FFF; font-style: bold; font-size:20px\">"+ rs.getString(23)+ "</td><td style=\"color: #FFF; font-style: bold; font-size:20px\">"+" Weightage8: " + "</td><td style=\"color: #FFF; font-style: bold; font-size:20px\">"+rs.getString(24)+"</td></tr>"+
						 "</table>");
 
			}
			ResultSet rs1 = ps1.executeQuery();
 
			while (rs1.next()) 
			{
				out.println("</br><font style=\"color: #FFF; font-style: bold; font-size:20px\">Premium:"+rs1.getInt(1));
			}
		
			out.println("</br></br><font style=\"color: #FFF; font-style: bold; font-size:20px\"><form> <input type=\"button\" value=\"Return to Home page\" onClick=\"javascript:history.go(-3)\" /> </form></font></body></html>");
		} catch (Exception e) {
			e.printStackTrace();
 
		} finally {
			out.close();
		}
		System.out.println("retrieved data");
 
	}
 
 
}