package controller;



	import java.io.IOException;
	import java.io.PrintWriter;
	import java.sql.Connection;
	import java.sql.DriverManager;
	import java.sql.PreparedStatement;
	import java.sql.ResultSet;

	import javax.servlet.ServletException;
	import javax.servlet.annotation.WebServlet;
	import javax.servlet.http.HttpServlet;
	import javax.servlet.http.HttpServletRequest;
	import javax.servlet.http.HttpServletResponse;

	@WebServlet("/Account2")
	public class Account2 extends HttpServlet
	{
		private static final long serialVersionUID = 1L;
	 
	    public Account2() {
	        super();
	        // TODO Auto-generated constructor stub
	    }
	 
		
		protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
			// TODO Auto-generated method stub
			
			response.setContentType("text/html");
			PrintWriter out = response.getWriter();

	        
			try { 
				Class.forName("oracle.jdbc.OracleDriver");
			
				Connection con = DriverManager.getConnection("jdbc:oracle:thin:"+"@10.219.34.3:1521/orcl","trg629","training629");
				PreparedStatement ps = con.prepareStatement("select account_number.nextval from dual");
				PreparedStatement ps1 = con.prepareStatement("select account_number.currval from dual");
				
				ResultSet rs = ps.executeQuery();
	 
				ResultSet rs1 = ps1.executeQuery();
	 
				while (rs1.next()) 
				{
					int a= rs1.getInt(1);
					int b=a-1;
					out.println("The Account number is : " + b);
					out.println("</br></br><a href='Agent.jsp'>Return to Agent</a>");
				}
				
			} catch (Exception e) {
				e.printStackTrace();
			} finally {
				out.close();
			}
			System.out.println("retrieved data");
		
		}
	 
	}

